import React, { Component, } from 'react'
import { View, Text, StyleSheet, Image, TextInput, Alert, ScrollView, TouchableOpacity, Dimensions, NetInfo, AsyncStorage} from 'react-native';
import Images from '../Themes/Images.js'          // Import Images.js class from Image Folder for images.
import Styles from './Styles/LoginScreenStyle'    // Import LoginScreenStyle.js class from Styles Folder to maintain UI.
import STRINGS from '../GlobalString/StringData'  // Import StringData.js class for string localization.
import {callPostApi} from '../Services/webApiHandler.js' // Import webApiHandler.js class for calling api.
import ActivityIndicator from '../Containers/ActivityIndicator' // Import ActivityIndicator class.
var GLOBAL = require('../Constants/global');                   // Import Global class for getting URLs.
import KeyboardSpacer from 'react-native-keyboard-spacer';     // Import keyboard spacer class for handling keyboard.
import {validateEmail} from '../Services/CommonValidation.js'  // Import CommonValidation class to access common methods for validations.

class Login extends Component {

constructor() {
  super()
  // Variable Declaration
  this.state = {
    username: '',
    password: '',
    animating: false,
    }
}
// Method calls when login button pressed and after validation of all fields, call login api.
onLoginPress() {
     if(this.state.username == ''){
        Alert.alert( 'Alert!', STRINGS.t('username_error_message'))
      }
     else if (!validateEmail(this.state.username)) {
        Alert.alert( 'Alert!', STRINGS.t('validation_email_error_message'))
      }
     else if(this.state.password.length < 6){
        Alert.alert('Alert!', STRINGS.t('password_error_message'))
      }
     else
     {
        this.callapi()
     }
}
componentDidMount() {
  NetInfo.isConnected.addEventListener(
    'change',
    this._handleConnectivityChange
  );
}
componentWillUnmount() {
  NetInfo.isConnected.removeEventListener(
    'change',
    this._handleConnectivityChange
  );
}
_handleConnectivityChange(status) {
  console.log('*********_handleConnectivityChange: Network Connectivity status *******: ' + status);

}
// Methods call for Login
callapi() {
    this.setState({animating: true});
    callPostApi(GLOBAL.BASE_URL + GLOBAL.Login_Api, {
      email: this.state.username,
      password: this.state.password,
    })
    .then((response) => {
            // Continue your code here...
              this.setState({animating: false});
              AsyncStorage.setItem("userDetail", result);    //Save user detail in local storage
              this.moveToDashboard()

      });
}
// Method to get saved data from local storage
getSavedData()
{
    AsyncStorage.getItem("userDetail").then((value) => {
    Alert.alert(
            'User Detail' + value
          );
    }).done();

}
// Method to move on signUp screen.
moveToSignUp()
{
   this.props.navigator.push({name: 'SignUp', index: 0 });
}
// Method to move on signUp screen.
moveToDashboard()
{
   this.props.navigator.push({name: 'Dashboard', index: 0 });
}
// Default render method and create UI for Login Screen
render() {
    return (

      <View style={Styles.backgroundImage}>


       <Image style={Styles.logoBackgroundStyle} source={Images.loginScreenBase}>
       <Image style={Styles.logoBackGround1} source={Images.logoImage} />
       <Image style={Styles.logoBackGround1} source={Images.costFirstText} />
       </Image>

        <ScrollView style={Styles.scroll_container}>
         <View style={Styles.viewContainer}>

          <View style={Styles.backgroundViewContainer}>
          <Image style = {Styles.logoImage} source={Images.username} />
          <TextInput placeholder={STRINGS.t('Username')} underlineColorAndroid = 'transparent' secureTextEntry={false} style={Styles.textInput}  returnKeyType ="next" keyboardType="email-address"  onChangeText={(val) => this.setState({username: val})} />
          </View>
          <View style={Styles.lineView}>
          </View>

          <ActivityIndicator animating = {this.state.animating}/>

          <View style={Styles.backgroundViewContainer}>
          <Image style = {Styles.logoImage} source={Images.password} />
          <TextInput placeholder={STRINGS.t('Password')} underlineColorAndroid = 'transparent' secureTextEntry={true} style={Styles.textInput}  onChangeText={(val) => this.setState({password: val})}/>
          </View>
          <View style={Styles.lineView}>
          </View>

          <TouchableOpacity style={Styles.buttonContainer} onPress={this.onLoginPress.bind(this)}>
          <Text style={Styles.style_btnLogin}> {STRINGS.t('Login')}</Text>
          </TouchableOpacity>

          <View style={Styles.checkBoxContainer}>
          <TouchableOpacity>
          <Image style={Styles.checkBoxStyles} source={Images.unselectedCheckbox} />
          </TouchableOpacity>
          <Text style={Styles.rememberMeStyles}>{STRINGS.t('Remember_Me')}</Text>
          </View>

          <View style={Styles.forgotContainer}>
          <Text style={Styles.forgotStyles}> {STRINGS.t('Forgot')} </Text>
          <TouchableOpacity>
          <Text style={Styles.usernameAndPasswordStyles}> {STRINGS.t('USERNAME')}</Text>
          </TouchableOpacity>
          <Text style={Styles.slashStyle}> / </Text>
          <TouchableOpacity>
          <Text style={Styles.usernameAndPasswordStyles}> {STRINGS.t('PASSWORD')}</Text>
          </TouchableOpacity>
          </View>

       <KeyboardSpacer/>
       </View>
       </ScrollView>


       <View style={Styles.footerlineView}>
       </View>
       <View style={Styles.footerContainer}>
       <Text style={Styles.memberStyles}> {STRINGS.t('Not_A_Member')} </Text>
       <TouchableOpacity onPress={this.moveToSignUp.bind(this)}>
       <Text style={Styles.usernameAndPasswordStyles}> {STRINGS.t('SIGNUP')}</Text>
       </TouchableOpacity>
       </View>
      </View>
    )
  }
}

export default Login
