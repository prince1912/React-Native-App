//
//  HomeViewController.m
//  ShopWhere
//
//  Created by Alok  on 5/7/15.
//  Copyright (c) 2015 alok. All rights reserved.
//

#import "HomeViewController.h"
#import "BusinessListViewController.h"
#import "UIKeyboardViewController.h"
#import "ContactUsViewController.h"
#import "WebViewController.h"
#import "WebCommunicationClass.h"
#import "NSString+SBJSON.h"
#import "BusinessDetailsViewController.h"
#import <CoreLocation/CoreLocation.h>



@interface HomeViewController ()<UIKeyboardViewControllerDelegate,UITableViewDataSource,UITableViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate,CLLocationManagerDelegate,UIScrollViewDelegate,UIAlertViewDelegate>
{
    __weak IBOutlet UITextField     *txt_SearchByKeyword;
    __weak IBOutlet UITextField     *txt_CityZipCode;
    __weak IBOutlet UITextField     *txt_Distance;
    __weak IBOutlet UIScrollView    *scrollViewCategoryBase;
    __weak IBOutlet UILabel         *lbl_PopUpHeaderTitle;
    IBOutlet UIView                 *viewCategoryBase;
    IBOutlet UIView                 *viewPopularSearchPopUp;
    __weak IBOutlet UITableView     *tbl_Places;

    UIKeyboardViewController    *keyBoardCntr;
    __weak IBOutlet UITableView *tbl_PopularSearch;
    
    NSArray             *arrPopularSearchInfo;    // For holding content of table item
    NSDictionary        *dictAllCategoriesDetails;// For Holding all categories list
    NSMutableArray      *arrCategory;             // For holding data of picker view category
    
    IBOutletCollection(UIButton) NSArray *btn_Categories;
    
    NSString      *strSearchForParam_1;
    NSString      *strSearchForParam_2;
    NSString      *strLat;
    NSString      *strLong;
     UIPickerView *pickerView;
     UIView       *pickerBaseView;
    NSInteger      selectedButtonTag;
    
    CLLocationManager *locationManager;
    
    // google places APIs properties
    
    NSMutableArray *arrPlaces;
}

@end

@implementation HomeViewController
@synthesize searchFor;
#pragma mark - View controller life Cycle
- (void)viewDidLoad {
    
    CGRect rect2 = self.view.frame;
    [super viewDidLoad];
    [self preLoadedUI];
    [self getAllCategoriesList_API];
    [self callPickerView];
    [pickerBaseView setHidden:YES];
    [self getCurrentLocation];
    
}

-(void)viewWillAppear:(BOOL)animated{
  tbl_PopularSearch.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero]; // To avoid extra seperator line
  [scrollViewCategoryBase setContentSize:CGSizeMake(320, 585)];
  scrollViewCategoryBase.contentOffset = CGPointMake(0,0);
  txt_SearchByKeyword.text = @"";
  txt_Distance.text = @"";
  txt_CityZipCode.text     = @"";
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(getAllCategoriesList_API_AtForeGround)
                                                 name:@"callCategory_DetailsAPI"
                                               object:nil];// This method will return all categories list
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(placeAutocomplete:) name:@"CallGooglePlacesAPI" object:nil];
    [self setCategoriesTitle];
}


-(void)viewWillDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)preLoadedUI{
    
    strLong = @"";
    strLat  = @"";
    txt_SearchByKeyword.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_Distance.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_CityZipCode.autocorrectionType = UITextAutocorrectionTypeNo;
    
    [scrollViewCategoryBase addSubview:viewCategoryBase];
    // For custom keyboard handler
    keyBoardCntr=[[UIKeyboardViewController alloc] initWithControllerDelegate:self];
    [keyBoardCntr changeStatus:YES];
    [keyBoardCntr addToolbarToKeyboard];// To add custom toolbar on controller
    
    
    dictAllCategoriesDetails = [[NSDictionary alloc]init];// This dictionary is holding all the categories details for perticular category
    arrPopularSearchInfo = [[NSArray alloc]init]; // This will hold search result of category
    arrCategory = [[NSMutableArray alloc]init]; // This will hold default category list
    arrPlaces=[[NSMutableArray alloc]init];// This will hold the data of google auto complete API
    
}
#pragma mark - All Button Actions

// All Search buttons action
- (IBAction)btn_Search_Tapped:(id)sender {
    
 
    [self hidePlacesTable];
    [self resignFromAllTextField];
    searchFor = normalSearch;
    BusinessListViewController *businessListVC  = [BusinessListViewController alloc];
    if(isIPAD){
        businessListVC =  [businessListVC initWithNibName:@"BusinessListViewController_iPad" bundle:nil];
    }
    else{
        businessListVC =  [businessListVC initWithNibName:@"BusinessListViewController" bundle:nil];
    }
    businessListVC.strSearchContent = txt_SearchByKeyword.text;
    if([txt_Distance.text isEqualToString:@""]){
        businessListVC.strDistance      = @"0";
    }
    else{
        businessListVC.strDistance      = [NSString stringWithFormat:@"%ld", [txt_Distance.text integerValue]];
    }
    
    businessListVC.strAddress      = txt_CityZipCode.text;
    businessListVC.searchFor = searchFor;
    businessListVC.strLat  = strLat;
    businessListVC.strLong = strLong;
    [self.navigationController pushViewController:businessListVC animated:YES];
    
    [arrPlaces removeAllObjects];
    
}

- (IBAction)btn_PopularSearch_Tapped:(id)sender {
    // This will return popular category of perticular area
    [self hidePlacesTable];
    [self resignFromAllTextField];
    searchFor = searchByPopularSearch;
    lbl_PopUpHeaderTitle.text = @"POPULAR SEARCHES";
    arrPopularSearchInfo = [dictAllCategoriesDetails valueForKey:@"popular_search"];
    
    [self.view addSubview:viewPopularSearchPopUp];
    [self.view bringSubviewToFront:viewPopularSearchPopUp];
    [tbl_PopularSearch reloadData];// Reload data of popular search table
}

- (IBAction)btn_LatestCategories_Tapped:(id)sender {
    // This will return latest categories list
    [self hidePlacesTable];
    [self resignFromAllTextField];
    searchFor = searchByLatest_catagory;
    lbl_PopUpHeaderTitle.text = @"LATEST CATEGORIES";
    arrPopularSearchInfo = [dictAllCategoriesDetails valueForKey:@"latest_catagory"];
    
    [self.view addSubview:viewPopularSearchPopUp];
    [self.view bringSubviewToFront:viewPopularSearchPopUp];
    [tbl_PopularSearch reloadData]; // will reload data of latest category
}

- (IBAction)btn_PopularSubCategories_Tapped:(id)sender {
    // This will show the result of sub categories
    [self hidePlacesTable];
    [self resignFromAllTextField];
    searchFor = searchByPopular_subcatagories;
    lbl_PopUpHeaderTitle.text = @"POPULAR SUBCATEGORIES";
    arrPopularSearchInfo = [dictAllCategoriesDetails valueForKey:@"popular_subcatagories "];
   
    [self.view addSubview:viewPopularSearchPopUp];
    [self.view bringSubviewToFront:viewPopularSearchPopUp];
    [tbl_PopularSearch reloadData];
}

- (IBAction)btn_LatestAdvertisment_Tapped:(id)sender {
    // This section will return the result of latest advertisment
    [self hidePlacesTable];
    [self resignFromAllTextField];
    searchFor = searchByLatest_advertisments;
    lbl_PopUpHeaderTitle.text = @"LATEST ADVERTISMENTS";
    arrPopularSearchInfo = [dictAllCategoriesDetails valueForKey:@"latest_advertisments"];
    
    [self.view addSubview:viewPopularSearchPopUp];
    [self.view bringSubviewToFront:viewPopularSearchPopUp];
    [tbl_PopularSearch reloadData];
}
//***************************************** Search Button Action END *************************************
// All Bottom buttons action

- (IBAction)btn_AboutUs_Tapped:(id)sender {
    // We are navigating to about us screen and showing html content over about us screen.
    [self hidePlacesTable];
   
    WebViewController *aboutVC = [WebViewController alloc];
    if(isIPAD){
        aboutVC =  [aboutVC initWithNibName:@"WebViewController_iPad" bundle:nil];
    }
    else{
        aboutVC =  [aboutVC initWithNibName:@"WebViewController" bundle:nil];
    }

    aboutVC.navigatingFor = About_US;
    [self.navigationController pushViewController:aboutVC animated:YES];
}

- (IBAction)btn_TermCondition_Tapped:(id)sender {
    // We are navigating to Term and condition screen and showing html content over terms and conditions screen.
    [self hidePlacesTable];
    
    WebViewController *termAndConditionVC = [[WebViewController alloc]init];
    if(isIPAD){
        termAndConditionVC =  [termAndConditionVC initWithNibName:@"WebViewController_iPad" bundle:nil];
    }
    else{
        termAndConditionVC =  [termAndConditionVC initWithNibName:@"WebViewController" bundle:nil];
    }

    termAndConditionVC.navigatingFor = Term_And_Condition;
    [self.navigationController pushViewController:termAndConditionVC animated:YES];
}

- (IBAction)btn_PrivacyPolicy_Tapped:(id)sender {
    // We are navigating to privacy policy screen and showing html content over privacy policy screen.
    [self hidePlacesTable];
    
    WebViewController *privacyPolicyVC = [[WebViewController alloc]init];
    if(isIPAD){
        privacyPolicyVC =  [privacyPolicyVC initWithNibName:@"WebViewController_iPad" bundle:nil];
    }
    else{
        privacyPolicyVC =  [privacyPolicyVC initWithNibName:@"WebViewController" bundle:nil];
    }

    privacyPolicyVC.navigatingFor = Privacy_Policy;
    [self.navigationController pushViewController:privacyPolicyVC animated:YES];
}

- (IBAction)btn_ContactUs_Tapped:(id)sender {
    // This will navigate to contact us screen
    [self hidePlacesTable];
    
    ContactUsViewController *contactUsVC = [ContactUsViewController alloc];
    if(isIPAD){
        contactUsVC =  [contactUsVC initWithNibName:@"ContactUsViewController_iPad" bundle:nil];
    }
    else{
        contactUsVC =  [contactUsVC initWithNibName:@"ContactUsViewController" bundle:nil];
    }
    [self.navigationController pushViewController:contactUsVC animated:YES];
}
//***************************************** Bottom Button Action END *************************************
// All Categories Button Action
- (IBAction)btn_Categories_Tapped:(id)sender {
    //This sction will show all the category list on picker view
    [self hidePlacesTable];
    UIButton *btnTapped = sender;
    selectedButtonTag   =  btnTapped.tag;
    [arrCategory removeAllObjects];
    NSDictionary *dictSuperCategory = [NSDictionary dictionaryWithObjectsAndKeys:[[[dictAllCategoriesDetails valueForKey:@"category"] objectAtIndex:btnTapped.tag-1]valueForKey:@"category_id"],@"subcat_id",[[[dictAllCategoriesDetails valueForKey:@"category"] objectAtIndex:btnTapped.tag-1]valueForKey:@"catgory_name"],@"subcat_name", nil];
    [arrCategory addObject:dictSuperCategory];
    [arrCategory  addObjectsFromArray:[[[dictAllCategoriesDetails valueForKey:@"category"] objectAtIndex:btnTapped.tag-1]valueForKey:@"subcategory"]];
    
    [pickerBaseView setHidden:NO];
    [pickerView reloadAllComponents];
    [pickerView selectRow:0 inComponent:0 animated:NO];
}

//***************************************** Category Button Action END *************************************

- (IBAction)btn_DistanceUp_Tapped:(id)sender {
    //From this scection we can manage distance
   [self hidePlacesTable];
    NSInteger distance = [txt_Distance.text integerValue];
    if([txt_Distance.text isEqualToString:@""]){
        distance = 5;
    }
    txt_Distance.text = [NSString stringWithFormat:@"%ld",distance+1];
}
- (IBAction)btn_DistanceDown_Tapped:(id)sender {
    //From this scection we can manage distance
   [self hidePlacesTable];
    NSInteger distance = [txt_Distance.text integerValue];
    if([txt_Distance.text isEqualToString:@""]){
        distance = 5;
    }
    if(distance>0)
    txt_Distance.text = [NSString stringWithFormat:@"%ld",distance-1];
}
- (IBAction)btn_RemovePopularSearch_Tapped:(id)sender {
    [viewPopularSearchPopUp removeFromSuperview];
}
- (IBAction)btn_NavigateToWebsite:(id)sender {
    [self hidePlacesTable];
    NSURL *url = [NSURL URLWithString:@"http://shopwhere.com.au/"];
    [[UIApplication sharedApplication] openURL:url];
    
}
- (IBAction)btn_Scroll_Tapped:(id)sender {
    [self hidePlacesTable];
}
#pragma mark- Table view data source and delegate 

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    // here we are maintaining multiple content in single table
    [tableView setSeparatorInset:UIEdgeInsetsZero];
    if([tableView isEqual:tbl_Places]){
        if([arrPlaces count]>0){
         [tbl_Places setHidden:NO];
            [self setAddressTableFrame];
        }
     return [arrPlaces count];
    }
    else{
    return [arrPopularSearchInfo count];
    }
    
    return 0;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    [tableView setSeparatorInset:UIEdgeInsetsMake(0, 0, 0, 0)];
    return 1;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIndentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIndentifier];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIndentifier];
    }
    
    if([tableView isEqual:tbl_Places]){
    cell.textLabel.text = [arrPlaces objectAtIndex:indexPath.row];
    }
    else{
    cell.textLabel.text = [[arrPopularSearchInfo objectAtIndex:indexPath.row]valueForKey:@"search_name"];
    }
    if(isIPAD)
    cell.textLabel.font = [UIFont fontWithName:@"OpenSans" size:14.0];
    else
    cell.textLabel.font = [UIFont fontWithName:@"OpenSans" size:11.0];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(isIPAD)
    return 50;
    else
    return 30;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    // From here we are navigating to description scree of category
    if([tableView isEqual:tbl_Places]){
        [txt_CityZipCode resignFirstResponder];
        if(arrPlaces.count>0)
        txt_CityZipCode.text = [arrPlaces objectAtIndex:indexPath.row];
        UITextPosition *firstCharacterPosition = [txt_CityZipCode beginningOfDocument];
        UITextPosition *secondCharacterPosition = [txt_CityZipCode positionFromPosition:firstCharacterPosition offset:0];
        UITextRange *firstCharacterRange = [txt_CityZipCode textRangeFromPosition:firstCharacterPosition toPosition:secondCharacterPosition];
        [txt_CityZipCode setSelectedTextRange:firstCharacterRange];
    }
    else{
    switch (searchFor) {
        case searchByPopularSearch:{
            strSearchForParam_1 = [[arrPopularSearchInfo objectAtIndex:indexPath.row]valueForKey:@"search_keyword_id"];
            [viewPopularSearchPopUp removeFromSuperview];
            
            BusinessDetailsViewController *businessDetailVC = [BusinessDetailsViewController alloc];
            if(isIPAD){
                businessDetailVC =  [businessDetailVC initWithNibName:@"BusinessDetailsViewController_iPad" bundle:nil];
            }
            else{
                businessDetailVC =  [businessDetailVC initWithNibName:@"BusinessDetailsViewController" bundle:nil];
            }
            businessDetailVC.searchFor = searchFor;
            businessDetailVC.strSearchForParam_1 = strSearchForParam_1;
            businessDetailVC.strSearchForParam_2 = strSearchForParam_2;
            businessDetailVC.strLat  = strLat;
            businessDetailVC.strLong = strLong;
            businessDetailVC.strSearchContent = txt_SearchByKeyword.text;
            if([txt_Distance.text isEqualToString:@""]){
                businessDetailVC.strDistance      = @"0";
            }
            else{
                businessDetailVC.strDistance      = [NSString stringWithFormat:@"%ld", (long)[txt_Distance.text integerValue]];
            }
            
            businessDetailVC.strAddress      = txt_CityZipCode.text;
            
            [self.navigationController pushViewController:businessDetailVC animated:YES];


            break;
        }
        case searchByLatest_catagory:{
            strSearchForParam_1 = [[arrPopularSearchInfo objectAtIndex:indexPath.row]valueForKey:@"category_id"];
            [viewPopularSearchPopUp removeFromSuperview];

            
            BusinessListViewController *businessListVC  = [BusinessListViewController alloc];
            if(isIPAD){
                businessListVC =  [businessListVC initWithNibName:@"BusinessListViewController_iPad" bundle:nil];
            }
            else{
                businessListVC =  [businessListVC initWithNibName:@"BusinessListViewController" bundle:nil];
            }
            businessListVC.strSearchForParam_1 = strSearchForParam_1;
            businessListVC.strSearchForParam_2 = strSearchForParam_2;
            businessListVC.strSearchContent = txt_SearchByKeyword.text;
            if([txt_Distance.text isEqualToString:@""]){
                businessListVC.strDistance      = @"0";
            }
            else{
                businessListVC.strDistance      = [NSString stringWithFormat:@"%ld", (long)[txt_Distance.text integerValue]];
            }
            
            businessListVC.strAddress      = txt_CityZipCode.text;
           // businessListVC.strSearchContent    = [[arrPopularSearchInfo objectAtIndex:indexPath.row]valueForKey:@"search_name"];
            businessListVC.searchFor = searchFor;
            businessListVC.strLat  = strLat;
            businessListVC.strLong = strLong;
            [self.navigationController pushViewController:businessListVC animated:YES];
            break;
        }
        case searchByPopular_subcatagories:{
            strSearchForParam_1 = [[arrPopularSearchInfo objectAtIndex:indexPath.row]valueForKey:@"subcat_id"];
            strSearchForParam_2 = [[arrPopularSearchInfo objectAtIndex:indexPath.row]valueForKey:@"cat_id"];
            [viewPopularSearchPopUp removeFromSuperview];

            BusinessListViewController *businessListVC  = [BusinessListViewController alloc];
            if(isIPAD){
                businessListVC =  [businessListVC initWithNibName:@"BusinessListViewController_iPad" bundle:nil];
            }
            else{
                businessListVC =  [businessListVC initWithNibName:@"BusinessListViewController" bundle:nil];
            }
            businessListVC.strSearchForParam_1 = strSearchForParam_1;
            businessListVC.strSearchForParam_2 = strSearchForParam_2;
            businessListVC.strSearchContent = txt_SearchByKeyword.text;
            if([txt_Distance.text isEqualToString:@""]){
                businessListVC.strDistance      = @"0";
            }
            else{
                businessListVC.strDistance      = [NSString stringWithFormat:@"%ld", (long)[txt_Distance.text integerValue]];
            }
            
            businessListVC.strAddress      = txt_CityZipCode.text;
           // businessListVC.strSearchContent    = [[arrPopularSearchInfo objectAtIndex:indexPath.row]valueForKey:@"search_name"];
            businessListVC.searchFor = searchFor;
            businessListVC.strLat  = strLat;
            businessListVC.strLong = strLong;
            [self.navigationController pushViewController:businessListVC animated:YES];
            break;
        }
        case searchByLatest_advertisments:{
            strSearchForParam_1 = [[arrPopularSearchInfo objectAtIndex:indexPath.row]valueForKey:@"search_keyword_id"];
            [viewPopularSearchPopUp removeFromSuperview];
            
            BusinessDetailsViewController *businessDetailVC = [BusinessDetailsViewController alloc];
            if(isIPAD){
                businessDetailVC =  [businessDetailVC initWithNibName:@"BusinessDetailsViewController_iPad" bundle:nil];
            }
            else{
                businessDetailVC =  [businessDetailVC initWithNibName:@"BusinessDetailsViewController" bundle:nil];
            }
            businessDetailVC.searchFor = searchFor;
            businessDetailVC.strSearchForParam_1 = strSearchForParam_1;
            businessDetailVC.strSearchForParam_2 = strSearchForParam_2;
            businessDetailVC.strLat  = strLat;
            businessDetailVC.strLong = strLong;
            businessDetailVC.strSearchContent = txt_SearchByKeyword.text;
            if([txt_Distance.text isEqualToString:@""]){
                businessDetailVC.strDistance      = @"0";
            }
            else{
                businessDetailVC.strDistance      = [NSString stringWithFormat:@"%ld", (long)[txt_Distance.text integerValue]];
            }
            
            businessDetailVC.strAddress      = txt_CityZipCode.text;
            [self.navigationController pushViewController:businessDetailVC animated:YES];
            break;
        }

        default:
            break;
    }
    }
    [self hidePlacesTable];
}
#pragma mark -  Web service Call
-(void)getAllCategoriesList_API_AtForeGround{
    strLong = @"";
    strLat  = @"";
    [self getAllCategoriesList_API];
    if([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]){
        [locationManager requestWhenInUseAuthorization];
    }else{
        [locationManager startUpdatingLocation];
    }
}
-(void)getAllCategoriesList_API{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getAllCategory) withObject:nil afterDelay:0.1];
}

-(void)getAllCategory{
    WebCommunicationClass   *aCommunication = [[WebCommunicationClass alloc]init];
    aCommunication.aCaller = self;
    [aCommunication getCategory_Details];

}
-(void)callSearchAPI{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(CallSearchBy) withObject:nil afterDelay:0.1];
   
}
-(void)CallSearchBy{
    WebCommunicationClass   *aCommunication = [[WebCommunicationClass alloc]init];
    aCommunication.aCaller = self;
    NSMutableDictionary *dictUserInfo = [[NSMutableDictionary alloc]init];
    
    switch (searchFor) {
        case normalSearch:{
            [dictUserInfo setObject:txt_SearchByKeyword.text forKey:@"search_text"];
            if([txt_Distance.text isEqualToString:@""]){
                [dictUserInfo setObject:@"0" forKey:@"location_range"];
            }
            else{
                [dictUserInfo setObject:txt_Distance.text forKey:@"location_range"];
            }
            [dictUserInfo setObject:txt_CityZipCode.text forKey:@"address"];
            break;
        }
        case searchByPopularSearch:{
            [dictUserInfo setObject:strSearchForParam_1 forKey:@"latest_search_id"];
            break;
        }
        case searchByLatest_catagory:{
            [dictUserInfo setObject:strSearchForParam_1 forKey:@"latest_search_id"];
            break;
        }
        case searchByPopular_subcatagories:{
            [dictUserInfo setObject:strSearchForParam_1 forKey:@"sub_cat_id"];
            [dictUserInfo setObject:strSearchForParam_2 forKey:@"category_id"];
            break;
        }
        case searchByLatest_advertisments:{
            [dictUserInfo setObject:strSearchForParam_1 forKey:@"category_id"];
            break;
        }
        case searchByCategory:{
            [dictUserInfo setObject:strSearchForParam_1 forKey:@"category_id"];
            break;
        }
        default:
            break;
    }
    
    if(isIPAD){
    [dictUserInfo setObject:@"iPad" forKey:@"device_type"];
    }
    else{
    [dictUserInfo setObject:@"iPhone" forKey:@"device_type"];
    }
    [aCommunication getSearchCategories:dictUserInfo];
}
#pragma mark response from server

-(void) dataDidFinishDowloading:(ASIHTTPRequest*)aReq withMethood:(NSString *)MethoodName withOBJ:(WebCommunicationClass *)aObj
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    NSString *aResult=[[NSString alloc] initWithData:[aReq responseData] encoding:NSUTF8StringEncoding];
    NSData *data = [aResult dataUsingEncoding:NSUTF8StringEncoding];
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSDictionary * dictResponse = [json valueForKey:@"item"];
    if(!dictResponse){
        dictResponse = (NSMutableDictionary*)json ;
    }
    if([[dictResponse valueForKey:@"status"]integerValue] == 200){
        if([[dictResponse valueForKey:@"api_name"]isEqualToString:@"Category_Details"]){
            // response for Category_Details API
            dictAllCategoriesDetails = dictResponse;
            [self setCategoriesTitle];
            
        }
        
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Message!" message:[json valueForKey:@"message"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }

}
-(void) dataDownloadFail:(ASIHTTPRequest*)aReq  withMethood:(NSString *)MethoodName
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    if([MethoodName isEqualToString:@"NetworkNotReachable"]){
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Network Error !" message:@"Internet connection is required." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        
    }
    else if ([MethoodName isEqualToString:@"ServerNotResponding"]){
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error !" message:@"There is some error while getting response. Please try again later." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
        UIAlertView *anAlertView=[[UIAlertView alloc]initWithTitle:@"Error !" message:@" Error From Server" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [anAlertView show];
    }
    
}

-(void)dataDidFinishDowloading_JSON_Serialization:(NSArray*)response
{
  [MBProgressHUD hideHUDForView:self.view animated:YES];
    
}

#pragma mark - Picker View Controller


- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}


- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [arrCategory count];
}


- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    
    
    return [[arrCategory objectAtIndex:row]valueForKey:@"subcat_name"];
    
    
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
}


-(void)callPickerView{
    pickerBaseView = [[UIView alloc]initWithFrame:appDelegate.window.frame];
    
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 280, 320, 44)];
    if(isIPAD){
        [toolbar setFrame:CGRectMake(0, 717, 768, 44)];
    }
    NSMutableArray *barItems = [[NSMutableArray alloc] init];
    UIBarButtonItem *flexSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    [barItems addObject:flexSpace];
    
    UIBarButtonItem *btnCancel = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelPickerAction:)];
    [barItems addObject:btnCancel];
    
    UIBarButtonItem *fixedItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    if(isIPAD)
    fixedItem.width = 625.0f;
    else
    fixedItem.width = 200.0f;
    [barItems addObject:fixedItem];
    
    UIBarButtonItem *btnDone = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(donePickerAction:)];
    [barItems addObject:btnDone];
    
    [toolbar setItems:barItems animated:YES];
    [pickerBaseView addSubview:toolbar];
    
    if(isIPAD)
    pickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 760, 768, 216)];
    else
    pickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 320, 320, 216)];
    
    pickerView.delegate=self;
    pickerView.dataSource=self;
    pickerView.showsSelectionIndicator=YES;
    pickerView.backgroundColor = [UIColor whiteColor];
    
    [pickerBaseView addSubview:pickerView];
    [self.view addSubview:pickerBaseView];
}

-(void)cancelPickerAction:(id)sender
{
    [pickerBaseView setHidden:YES];
}
-(void)donePickerAction:(id)sender
{
    searchFor = searchByCategory;
    [pickerBaseView setHidden:YES];
    strSearchForParam_1 = [[arrCategory objectAtIndex:[pickerView selectedRowInComponent:0]] valueForKey:@"subcat_id"];
    NSString *strCatName = [[arrCategory objectAtIndex:[pickerView selectedRowInComponent:0]] valueForKey:@"subcat_name"];
    [self setCategoriesTitleOnButton:strCatName];
    if(strSearchForParam_1!=nil && ![strSearchForParam_1 isEqualToString:@""]){
    BusinessListViewController *businessListVC  = [BusinessListViewController alloc];
        if(isIPAD){
            businessListVC =  [businessListVC initWithNibName:@"BusinessListViewController_iPad" bundle:nil];
        }
        else{
            businessListVC =  [businessListVC initWithNibName:@"BusinessListViewController" bundle:nil];
        }
        businessListVC.strSearchContent = txt_SearchByKeyword.text;
        if([txt_Distance.text isEqualToString:@""]){
            businessListVC.strDistance      = @"0";
        }
        else{
            businessListVC.strDistance      = [NSString stringWithFormat:@"%ld", (long)[txt_Distance.text integerValue]];
        }
        
    businessListVC.strAddress      = txt_CityZipCode.text;
    businessListVC.strSearchForParam_1 = strSearchForParam_1;
    businessListVC.searchFor = searchFor;
    businessListVC.strLat  = strLat;
    businessListVC.strLong = strLong;
    [self.navigationController pushViewController:businessListVC animated:YES];
    }
}

#pragma mark -Alert View delegate 
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 100 && buttonIndex == 0)
    {
        //code for opening settings app in iOS 8
        [[UIApplication sharedApplication] openURL:[NSURL  URLWithString:UIApplicationOpenSettingsURLString]];
    }
}
#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    // If failed to get user location
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    // Successfully get user latitude and longitude
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    
    if (currentLocation != nil) {
        strLong = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        strLat = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
        [locationManager stopUpdatingLocation];
    }
    else{
        strLong = @"";
        strLat  = @"";
    }
}
-(void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    switch (status) {
        case kCLAuthorizationStatusNotDetermined:
        case kCLAuthorizationStatusRestricted:
        case kCLAuthorizationStatusDenied:
        {
            // do some error handling
        }
        break;
        default:{
            [locationManager startUpdatingLocation];
        }
        break;
    }
}

#pragma mark- Google Places APIs

- (void)placeAutocomplete:(NSNotification*)notificaiton {
    // This section will return autocomplete address on the basis of input text
    NSString *strLastChar = notificaiton.object;
    NSString *url=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@%@&types=geocode&language=en&components=country:aus&sensor=true&key=AIzaSyDjOXc8LmK_Ldh-deugUwX6q5QxiUHItPk",txt_CityZipCode.text,strLastChar];
    url = [url stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    NSURLRequest *theRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    NSURLResponse *resp = nil;
    NSError *err = nil;
    
    NSData *response = [NSURLConnection sendSynchronousRequest: theRequest returningResponse: &resp error: &err];
    if(response){
    NSArray *jsonArray = [NSJSONSerialization JSONObjectWithData: response options: NSJSONReadingMutableContainers error: &err];
    
    if (!jsonArray) {
        NSLog(@"Error parsing JSON: %@", err);
    } else {
        [arrPlaces removeAllObjects];
        for (NSDictionary *dictData in [jsonArray valueForKey:@"predictions"]){
            [arrPlaces addObject:[dictData valueForKey:@"description"]];
        }
        if([arrPlaces count]>0){
            [tbl_Places reloadData];
        }
    }
    }
}


#pragma mark - Other Methods

-(void)setAddressTableFrame{
    // Here managing table to frame according to number of result return in autocomplete API
    switch ([arrPlaces count]) {
        case 1:
            if(isIPAD)
            [tbl_Places setFrame:CGRectMake(140, 148, 600, 50)];
            else
            [tbl_Places setFrame:CGRectMake(112, 117, 188, 30)];
            break;
        case 2:
            if(isIPAD)
            [tbl_Places setFrame:CGRectMake(140, 148, 600, 99)];
            else
            [tbl_Places setFrame:CGRectMake(112, 117, 188, 59)];
            break;
        case 3:
            if(isIPAD)
            [tbl_Places setFrame:CGRectMake(140, 148, 600, 149)];
            else
            [tbl_Places setFrame:CGRectMake(112, 117, 188, 89)];
            break;
        case 4:
            if(isIPAD)
            [tbl_Places setFrame:CGRectMake(140, 148, 600, 199)];
            else
            [tbl_Places setFrame:CGRectMake(112, 117, 188, 119)];
            break;
        default:
            if(isIPAD)
            [tbl_Places setFrame:CGRectMake(140, 148, 600, 249)];
            else
            [tbl_Places setFrame:CGRectMake(112, 117, 188, 149)];
            break;
    }
}
-(void)setCategoriesTitle{
    NSArray *arrAllCategoriesInfo = [dictAllCategoriesDetails valueForKey:@"category"];
   // here we are setting button title as per categories sets
    for(int i=0; i<[btn_Categories count]; i++){
     UIButton *btn_Cat = [btn_Categories objectAtIndex:i];
      [btn_Cat setTitle:[[arrAllCategoriesInfo objectAtIndex:i]valueForKey:@"catgory_name"] forState:UIControlStateNormal];
    }
}

-(void)getCurrentLocation{
    // Here we are getting current location of user
     locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyThreeKilometers;
    if([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]){
        [locationManager requestWhenInUseAuthorization];
    }else{
        [locationManager startUpdatingLocation];
    }
}

-(void)setCategoriesTitleOnButton:(NSString*)title{
    UIButton *btn_Cat = [btn_Categories objectAtIndex:selectedButtonTag-1];
    [btn_Cat setTitle:title forState:UIControlStateNormal];
}


-(void)resignFromAllTextField{
    [txt_SearchByKeyword resignFirstResponder];
    [txt_Distance resignFirstResponder];
    [txt_CityZipCode resignFirstResponder];
}

-(void)hidePlacesTable{
    [tbl_Places setHidden:YES];
    [arrPlaces removeAllObjects];
}
#pragma mark - Touch Methods 

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self hidePlacesTable];

}

#pragma mark - Scroll View Delegate 

-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
  [self hidePlacesTable];
}
- (BOOL)touchesShouldBegin:(NSSet *)touches withEvent:(UIEvent *)event inContentView:(UIView *)view{
    return YES;
}
#pragma mark - Text field delegate
- (void)alttextFieldDidBeginEditing:(UITextField *)textField{
    if([textField isEqual:txt_Distance] && [txt_Distance.text isEqualToString:@""] && [strLat isEqualToString:@""]){
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Please enable your location to get accurate search result." message:nil delegate:self cancelButtonTitle:@"YES" otherButtonTitles:@"NO", nil];
        alert.tag = 100;
        [alert show];
    }
  [self hidePlacesTable];  
}
@end
