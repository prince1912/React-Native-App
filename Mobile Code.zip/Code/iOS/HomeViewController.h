//
//  HomeViewController.h
//  ShopWhere
//
//  Created by Alok  on 5/7/15.
//  Copyright (c) 2015 alok. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController
{
}
typedef enum SearchFor {
    normalSearch ,
    searchByPopularSearch ,
    searchByLatest_catagory,
    searchByPopular_subcatagories,
    searchByLatest_advertisments,
    searchByCategory
} SearchFor;
@property(assign)SearchFor searchFor;
@end
